import numpy as np
import vtk
from vtk import *
from vtk.util import numpy_support as ns

# Step1 : Loading 2D data

reader = vtk.vtkXMLImageDataReader()
reader.SetFileName('Data\Isabel_2D.vti')
reader.Update()
data = reader.GetOutput()

# Step2 : Save all values of points in the Data_Value_Array

Data_Value_Array = ns.vtk_to_numpy(data.GetPointData().GetArray('Pressure'))

# Take input the isovalue in the pressure range
ISOVALUE = float(input("Enter the isovalue of pressure for the contour line in range : "+str(min(Data_Value_Array))+' to '+str(max(Data_Value_Array))+'\n') )
if(ISOVALUE < min(Data_Value_Array) or ISOVALUE > max(Data_Value_Array)):
    print("Isovalue is not in pressure range of the dataset. So, isocontour is empty.")
    exit()

# MARCHING SQUARE ALGORITHM IMPLEMENTATION :
# Step3 : Now, we find all the active cells (cells where have all verices values are not less and not more than ISOVALUE)

Active_cell_list = []  # List containing Cell-id's of all Active cells

# Below loop appends Cell-id of all active cells in the list
i=0
while i<=62000:
    cid = i
    cell_object_curr = data.GetCell(cid)
    point1 = cell_object_curr.GetPointId(0)
    point2 = cell_object_curr.GetPointId(1)
    point3 = cell_object_curr.GetPointId(2)
    point4 = cell_object_curr.GetPointId(3)
    if(not((Data_Value_Array[point1] > ISOVALUE and Data_Value_Array[point2] > ISOVALUE and Data_Value_Array[point3] > ISOVALUE and Data_Value_Array[point4] > ISOVALUE) or ((Data_Value_Array[point1] < ISOVALUE and Data_Value_Array[point2] < ISOVALUE and Data_Value_Array[point3] < ISOVALUE and Data_Value_Array[point4] < ISOVALUE)))):
        Active_cell_list.append(cid)
    i = i+1

# Step4 : Iterating over all active cells and finding the coordinates of all points where the isocontour cuts the cells

master_list = []    # List containing coordinates(x,y,z) of all Isocontour points cutting the all cells
for j in Active_cell_list:
    cid = j
    cell_object_current = data.GetCell(cid)
    p = []
    mid_point = []  # List storing coordinates of all intersection points of isocontour
    p.append(cell_object_current.GetPointId(0))
    p.append(cell_object_current.GetPointId(1))
    p.append(cell_object_current.GetPointId(3))
    p.append(cell_object_current.GetPointId(2))

    # pt0, pt1, pt2 & pt3 are vertices of cell stored in Anti-clockwise manner

    pt0 = cell_object_current.GetPointId(0)
    pt1 = cell_object_current.GetPointId(1)
    pt2 = cell_object_current.GetPointId(3)
    pt3 = cell_object_current.GetPointId(2)
    for x in range(0,4):
        if(Data_Value_Array[p[x]] > ISOVALUE):
            p[x] = 1
        else:
            p[x] = 0

    # Moving in anti-clockwise manner to resolve ambiguity.
    # Checking for each edge ACW if the isocontour passes through it. If yes, then we append the coordinate of isocontour in the master_list.
    if(p[0] != p[1]):
        l = []
        t = (((ISOVALUE-Data_Value_Array[pt0])/(Data_Value_Array[pt1]-Data_Value_Array[pt0]))*(data.GetPoint(pt1)[0]-data.GetPoint(pt0)[0])) + (data.GetPoint(pt0)[0])
        l.append(t)
        l.append(data.GetPoint(pt0)[1])
        l.append(25.0)
        mid_point.append(l)
    if(p[1] != p[2]):
        l = []
        t = (((ISOVALUE-Data_Value_Array[pt1])/(Data_Value_Array[pt2]-Data_Value_Array[pt1]))*(data.GetPoint(pt2)[1]-data.GetPoint(pt1)[1])) + (data.GetPoint(pt1)[1])
        l.append(data.GetPoint(pt1)[0])
        l.append(t)
        l.append(25.0)
        mid_point.append(l)
    if(p[2] != p[3]):
        l = []
        t = (((ISOVALUE-Data_Value_Array[pt3])/(Data_Value_Array[pt2]-Data_Value_Array[pt3]))*(data.GetPoint(pt2)[0]-data.GetPoint(pt3)[0])) + (data.GetPoint(pt3)[0])
        l.append(t)
        l.append(data.GetPoint(pt2)[1])
        l.append(25.0)
        mid_point.append(l)
    if(p[3] != p[0]):
        l = []
        t = (((ISOVALUE-Data_Value_Array[pt0])/(Data_Value_Array[pt3]-Data_Value_Array[pt0]))*(data.GetPoint(pt3)[1]-data.GetPoint(pt0)[1])) + (data.GetPoint(pt0)[1])
        l.append(data.GetPoint(pt3)[0])
        l.append(t)
        l.append(25.0)
        mid_point.append(l)
    master_list.append(mid_point)


# Step5: Adding vtkPoints of all the coordinates in master_list 

points = vtk.vtkPoints()
cells = vtk.vtkCellArray()
no_line = 0


for mid_point in master_list:
    if(len(mid_point) == 2):
        points.InsertNextPoint(mid_point[0])
        points.InsertNextPoint(mid_point[1])
        no_line += 1

    else:
        points.InsertNextPoint(mid_point[0])
        points.InsertNextPoint(mid_point[1])
        points.InsertNextPoint(mid_point[2])
        points.InsertNextPoint(mid_point[3])
        no_line += 2

# Step6: Adding isocontour lines form the points added above

t=0   
for x in range(0,(no_line*2)):
    line = vtk.vtkLine()
    line.GetPointIds().SetId(0, t)
    t = t+1
    line.GetPointIds().SetId(1, t)
    t = t + 1
    cells.InsertNextCell(line)

# Adding points and lines to vtkPolyData
pdata = vtk.vtkPolyData()
pdata.SetPoints(points)
pdata.SetLines(cells)

# Writing the polydata to 'isocontour.vtp' file.

writer = vtk.vtkXMLPolyDataWriter()
writer.SetInputData(pdata)
writer.SetFileName('isocontour.vtp')
writer.Write()
print("The extracted isocontour for the input isovalue is stored in \'isocontour.vtp\' file. ")