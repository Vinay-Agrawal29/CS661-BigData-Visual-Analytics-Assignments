import numpy as np
import vtk
from vtk import *
from vtk.util import numpy_support as ns


# 1.) Loading the 3-D data provided :

reader = vtk.vtkXMLImageDataReader()
reader.SetFileName('Data\Isabel_3D.vti')
reader.Update()
data = reader.GetOutputPort()
# print(data)



# 2.) Instance for vtk color transfer function

colourTf = vtk.vtkColorTransferFunction()
colourTf.AddRGBPoint(-4931.54, 0.0 , 1.0 , 1.0)
colourTf.AddRGBPoint(-2508.95, 0.0, 0.0, 1.0)
colourTf.AddRGBPoint(-1873.9, 0.0, 0.0, 0.5)
colourTf.AddRGBPoint(-1027.16 , 1.0, 0.0, 0.0)
colourTf.AddRGBPoint(-298.031 , 1.0, 0.4, 0.0)
colourTf.AddRGBPoint(2594.97, 1.0, 1.0, 0.0)

# 3.) Instance for vtk opacity transfer function

opacityTf = vtk.vtkPiecewiseFunction()
opacityTf.AddPoint(-4931.54, 1.0)
opacityTf.AddPoint(101.815 , 0.002)
opacityTf.AddPoint(2594.97 , 0.0)

# 4.) vtkSmartVolumeMapper() class to perform the volume rendering

volume_mapper = vtk.vtkSmartVolumeMapper()
volume_mapper.SetInputConnection(data)

# 5.) Adding volume properties

volume_property = vtk.vtkVolumeProperty()
volume_property.SetColor(colourTf)
volume_property.SetScalarOpacity(opacityTf)

# 6.) Adding the volume actor

volume = vtk.vtkVolume()
volume.SetMapper(volume_mapper)
volume.SetProperty(volume_property)

# 7.)  vtkOutlineFilter to add an outline to the volume rendered data 
outline_filter = vtk.vtkOutlineFilter()
outline_filter.SetInputConnection(reader.GetOutputPort())

# 8.) Creating the outline mapper
outline_mapper = vtk.vtkPolyDataMapper()
outline_mapper.SetInputConnection(outline_filter.GetOutputPort())

# 9.) Adding the outline actor
outline = vtk.vtkActor()
outline.SetMapper(outline_mapper)
outline.GetProperty().SetColor(0, 0, 0)

# Ask the user if you want to enable Phong shading
phong_shading = input("If you want to enable Phong Shading type \'yes\' else type \'no\'.\n")

# 10.) Creating the renderer and render window
renderer = vtk.vtkRenderer()
renderer.AddVolume(volume)
renderer.AddActor(outline)
colors = vtk.vtkNamedColors()
renderer.SetBackground(colors.GetColor3d('White'))


render_window = vtk.vtkRenderWindow()
render_window.AddRenderer(renderer)
render_window.SetSize(1000, 1000)
render_window.SetWindowName('Phong shading ----> '+ '(' + phong_shading + ')')


if phong_shading.lower() == "yes":
    volume_property.ShadeOn()
    # Setting Phong Shading Parameters
    volume.GetProperty().SetAmbient(0.5)
    volume.GetProperty().SetDiffuse(0.5)
    volume.GetProperty().SetSpecular(0.5)
else:
    volume.GetProperty().ShadeOff()

# interaction (showing the output in render window)
render_window_interactor = vtk.vtkRenderWindowInteractor()
render_window_interactor.SetRenderWindow(render_window)
render_window_interactor.Initialize()
render_window_interactor.Start()