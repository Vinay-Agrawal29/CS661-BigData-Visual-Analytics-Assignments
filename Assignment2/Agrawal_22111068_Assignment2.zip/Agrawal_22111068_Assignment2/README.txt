To run the solution for the first question:-
# Command :- (inside the folder) 

python Solution1.py

After entering the above command it asks :-

Enter the isovalue of pressure for the contour line in range : -1434.8590087890625 to 630.5694580078125 

Where you have to enter the isovalue for the contour in the above range. Ater this a file named 'isocontour.vtp' will be generated inside the same folder
which has the isocontour the specified isovalue on the given 2D data. This file can be viewed in paraview.


To run the solution for the second question:-

# Command :- (inside the folder)

python Solution2.py

After entering the above command it asks :-

If you want to enable Phong Shading type 'yes' else type 'no'.

Here, while viewing the 3D dataset, if you want to apply phong shading, type 'yes' without quotes else type 'no'. After entering a render window shows the 
desired result.