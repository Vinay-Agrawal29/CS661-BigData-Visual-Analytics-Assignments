import numpy as np
from vtk import *
from vtk.util import numpy_support as ns



# Loading the 2D data
reader = vtkXMLImageDataReader()
reader.SetFileName('Isabel_2D.vti')
reader.Update()
data = reader.GetOutput()


print("---------------------------------------------------------")
print('Question-1 : Data Query/Processing Task')
print("---------------------------------------------------------")



# 1.) Number of cells in dataset
numCells = data.GetNumberOfCells()
print('No. of cells in dataset =' , numCells)



# 2.) Dimension of dataset
dim = data.GetDimensions()
print("Dimension of dataset = ", dim)



# 3.) Number of points in uniform grid of data
num_points = dim[0]*dim[1]*dim[2]                                                         # Product of dimensions along 3 axes
print('Number of points present in uniform grid of data = ', num_points)



# 4.) Range of pressure values present in dataset 
Data_Value_Array = ns.vtk_to_numpy(data.GetPointData().GetArray('Pressure'))              # Storing all point values in a numpy array (Data_Value_Array)
max_val = np.max(Data_Value_Array)
min_val = np.min(Data_Value_Array)
print('Range of pressure values in dataset is from -','[',min_val,' to ',max_val,']')



# 5.) Average pressure value
average_pressure = np.average(Data_Value_Array)
print('Average pressure value of entire dataset is = ' ,average_pressure )




# 6.) Extract VTK cell object with Cell id = __ 
cell_id = 0                                                                                # -- Can change cell id here 
cell_object = data.GetCell(cell_id)
print('Cell object :',cell_object)




# 7.) Print indices of four corner vertices of cell
point1 = cell_object.GetPointId(0)
point2 = cell_object.GetPointId(1)
point3 = cell_object.GetPointId(2)
point4 = cell_object.GetPointId(3)
print('Indices of corner vertices of cell(',cell_id,') are :')
print(point1,',',point2,',',point3,',',point4)



# 8.) Print the 3D coordinate of each vertex
print('3D coordinate in form (x,y,z) of 4 vertices of cell are : ')
print(data.GetPoint(point1))
print(data.GetPoint(point2))
print(data.GetPoint(point3))
print(data.GetPoint(point4))



# 9.) Compute 3D coordinate of center of the cell
list_of_vertices = [data.GetPoint(point1),data.GetPoint(point2),data.GetPoint(point3),data.GetPoint(point4)]
center_x = (data.GetPoint(point1)[0]+data.GetPoint(point2)[0]+data.GetPoint(point3)[0]+data.GetPoint(point4)[0])/4     # Average of all x-coordinate values
center_y = (data.GetPoint(point1)[1]+data.GetPoint(point2)[1]+data.GetPoint(point3)[1]+data.GetPoint(point4)[1])/4     # Average of all y-coordinate values
center_z = 25.0                                                                                                        # z-axis constant i.e. 25
print('3D coordinate (x,y,z) of center of cell(',cell_id,') are :') 
print('(',center_x,',',center_y,',',center_z,')')



# 10.) Pressure value of all four vertices of extracted cell
print('Pressure value at first vertex = ',Data_Value_Array[point1])                      # Simple access of values from the data value array
print('Pressure value at second vertex = ',Data_Value_Array[point2])
print('Pressure value at third vertex = ',Data_Value_Array[point3])
print('Pressure value at fourth vertex = ',Data_Value_Array[point4])



# 11.) Average pressure at center of cell
center_avg_pressure = (Data_Value_Array[point1]+Data_Value_Array[point2]+Data_Value_Array[point3]+Data_Value_Array[point4])/4     # Avg. value of all corner vertices
print('Mean pressure value at cell center = ',center_avg_pressure)


print("---------------------------------------------------------")
print('Question-2 : Visualization Task')
print("---------------------------------------------------------")

colors = vtkNamedColors()

points = vtkPoints()

# Inserting corner vertices to points of a cell
points.InsertNextPoint(data.GetPoint(cell_object.GetPointId(0)))
points.InsertNextPoint(data.GetPoint(cell_object.GetPointId(1)))
points.InsertNextPoint(data.GetPoint(cell_object.GetPointId(2)))
points.InsertNextPoint(data.GetPoint(cell_object.GetPointId(3)))

# Setting colours to the corner vertices
Colors = vtkUnsignedCharArray()
Colors.SetNumberOfComponents(4)
Colors.SetName('Colors')
Colors.InsertNextTuple4(*colors.GetColor4ub('Red'))
Colors.InsertNextTuple4(*colors.GetColor4ub('Lime'))
Colors.InsertNextTuple4(*colors.GetColor4ub('Blue'))
Colors.InsertNextTuple4(*colors.GetColor4ub('Cyan'))

# Creating poltdata object
pdata = vtkPolyData()
pdata.SetPoints(points)
pdata.GetPointData().SetScalars(Colors)
pdata.Modified()

# Creating visual representation for each point in form of Vertex Glyph
vertexGlyphFilter = vtkVertexGlyphFilter()
vertexGlyphFilter.AddInputData(pdata)
vertexGlyphFilter.Update()

mapper = vtkPolyDataMapper()
mapper.SetInputConnection(vertexGlyphFilter.GetOutputPort())

actor = vtkActor()
actor.SetMapper(mapper)
actor.GetProperty().SetPointSize(15)

# Creating a renderer, render window, and interactor
renderer = vtkRenderer()
renderWindow = vtkRenderWindow()
renderWindow.AddRenderer(renderer)
renderWindowInteractor = vtkRenderWindowInteractor()
renderWindowInteractor.SetRenderWindow(renderWindow)

# Adding the actor 
renderer.AddActor(actor)
renderer.SetBackground(colors.GetColor3d('White'))

# Rendering and interaction
renderWindow.SetWindowName('Visualization Toolkit - One Cell looks like :- ')
renderWindow.Render()
renderWindowInteractor.Start()